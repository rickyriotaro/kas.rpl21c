<?php 
	require 'connection.php';
	session_destroy();
	logout();
?>
